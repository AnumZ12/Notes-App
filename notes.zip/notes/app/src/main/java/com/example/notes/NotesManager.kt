package com.example.notesapp

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val title: String,
    val description: String,
    val date: String
)

class NotesManager(context: Context) {
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences("NotesPref", Context.MODE_PRIVATE)

    fun getAllNotes(): List<Note> {
        val notesList = mutableListOf<Note>()
        val notesString = sharedPreferences.getString("notes", "[]")
        val jsonArray = JSONArray(notesString)
        for (i in 0 until jsonArray.length()) {
            val jsonObject = jsonArray.getJSONObject(i)
            notesList.add(
                Note(
                    title = jsonObject.getString("title"),
                    description = jsonObject.getString("description"),
                    date = jsonObject.getString("date")
                )
            )
        }
        return notesList
    }

    fun saveNote(note: Note) {
        val notesList = getAllNotes().toMutableList()
        notesList.add(note)
        val jsonArray = JSONArray()
        for (n in notesList) {
            val jsonObject = JSONObject()
            jsonObject.put("title", n.title)
            jsonObject.put("description", n.description)
            jsonObject.put("date", n.date)
            jsonArray.put(jsonObject)
        }
        sharedPreferences.edit().putString("notes", jsonArray.toString()).apply()
    }
}
