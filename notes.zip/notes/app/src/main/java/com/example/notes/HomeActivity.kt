package com.example.notes

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.notesapp.NotesManager
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeActivity : AppCompatActivity() {
    private lateinit var notesManager: NotesManager
    private lateinit var notesAdapter: ArrayAdapter<String>
    private lateinit var notesListView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        notesManager = NotesManager(this)
        notesListView = findViewById(R.id.notesListView)
        val fabAddNote: FloatingActionButton = findViewById(R.id.fabAddNote)

        fabAddNote.setOnClickListener {
            startActivity(Intent(this, AddNoteActivity::class.java))
        }

        notesListView.setOnItemClickListener { _, _, position, _ ->
            val note = notesManager.getAllNotes()[position]
            val intent = Intent(this, NoteDetailActivity::class.java)
            intent.putExtra("title", note.title)
            intent.putExtra("description", note.description)
            intent.putExtra("date", note.date)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        loadNotes()
    }

    private fun loadNotes() {
        val notes = notesManager.getAllNotes()
        val notesAdapter = NotesAdapter(this, notes)
        notesListView.adapter = notesAdapter
    }

}
