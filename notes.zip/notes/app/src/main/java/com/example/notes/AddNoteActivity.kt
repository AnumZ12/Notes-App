package com.example.notes

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.notesapp.Note
import com.example.notesapp.NotesManager
import java.text.SimpleDateFormat
import java.util.*

class AddNoteActivity : AppCompatActivity() {
    private lateinit var notesManager: NotesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_note)

        notesManager = NotesManager(this)
        val edtTitle: EditText = findViewById(R.id.edtTitle)
        val edtDescription: EditText = findViewById(R.id.edtDescription)
        val btnSave: Button = findViewById(R.id.btnSave)

        btnSave.setOnClickListener {
            val title = edtTitle.text.toString()
            val description = edtDescription.text.toString()
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            if (title.isNotEmpty() && description.isNotEmpty()) {
                notesManager.saveNote(Note(title, description, date))
                finish()
            }
        }
    }
}
